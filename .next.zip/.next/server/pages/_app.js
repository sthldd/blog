module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("1TCz");


/***/ }),

/***/ "1TCz":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__("zPlV");

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: ./node_modules/antd/dist/antd.css
var antd = __webpack_require__("TpwP");

// EXTERNAL MODULE: ./node_modules/highlight.js/styles/atom-one-light.css
var atom_one_light = __webpack_require__("7+C2");

// EXTERNAL MODULE: ./node_modules/react-markdown-editor-lite/lib/index.css
var lib = __webpack_require__("i8oR");

// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__("Exp3");

// CONCATENATED MODULE: ./components/LayoutHeader.tsx

var __jsx = external_react_default.a.createElement;

const {
  Header
} = external_antd_["Layout"];
const LayoutHeader = props => {
  return __jsx(Header, {
    className: "layout_header"
  }, __jsx("div", {
    className: "header_title"
  }, "LIFE IS A FUCKING MOVIE"));
};
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// CONCATENATED MODULE: ./pages/_app.js

var _app_jsx = external_react_default.a.createElement;







const {
  Footer,
  Sider,
  Content
} = external_antd_["Layout"];

var arr = ['/sign_in', '/sign_up', '/', 'page=', '/record', '/tags'];

function MyApp({
  Component,
  pageProps
}) {
  const {
    asPath
  } = Object(router_["useRouter"])();
  const router = Object(router_["useRouter"])();

  const handleOk = key => {
    if (key.key === '1') {
      router.push('/backstage/articleList/list');
    } else {
      router.push('/backstage/tagsList');
    }
  };

  const match = path => {
    var result;

    for (let i = 0; i < arr.length; i++) {
      if (arr[i].includes(path)) {
        result = true;
        break;
      }

      if (path.includes('/?page=') || path.includes('/posts/') || path.includes('/tags#')) {
        result = true;
        break;
      } else {
        result = false;
      }
    }

    return result;
  };

  return _app_jsx(external_react_default.a.Fragment, null, _app_jsx(head_default.a, null, _app_jsx("title", null, "\u8A18"), _app_jsx("meta", {
    name: "viewport",
    content: "width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"
  }), _app_jsx("link", {
    rel: "stylesheet",
    href: "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/10.6.0/styles/default.min.css"
  })), match(asPath) ? _app_jsx(Component, pageProps) : _app_jsx(external_react_default.a.Fragment, null, _app_jsx(external_antd_["Layout"], {
    style: {
      height: '100vh'
    }
  }, _app_jsx(Sider, {
    breakpoint: "lg",
    collapsedWidth: "0"
  }, _app_jsx("div", {
    className: "logo"
  }), _app_jsx(external_antd_["Menu"], {
    theme: "dark",
    mode: "inline",
    defaultSelectedKeys: ['1'],
    style: {
      height: '100%',
      borderRight: 0
    },
    onClick: handleOk
  }, _app_jsx(external_antd_["Menu"].Item, {
    key: "1"
  }, "\u6587\u7AE0\u5217\u8868"), _app_jsx(external_antd_["Menu"].Item, {
    key: "2"
  }, "\u6807\u7B7E\u5217\u8868"))), _app_jsx(external_antd_["Layout"], null, _app_jsx(LayoutHeader, null), _app_jsx(Content, {
    style: {
      margin: '24px 16px 0'
    }
  }, _app_jsx(Component, pageProps)), _app_jsx(Footer, {
    style: {
      textAlign: 'center'
    }
  }, "Ant Design \xA92018 Created by Ant UED"))), _app_jsx("script", {
    src: "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/10.6.0/highlight.min.js"
  })));
}

/* harmony default export */ var _app = __webpack_exports__["default"] = (MyApp);

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "7+C2":
/***/ (function(module, exports) {



/***/ }),

/***/ "Exp3":
/***/ (function(module, exports) {

module.exports = require("antd");

/***/ }),

/***/ "TpwP":
/***/ (function(module, exports) {



/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "i8oR":
/***/ (function(module, exports) {



/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "zPlV":
/***/ (function(module, exports) {



/***/ })

/******/ });