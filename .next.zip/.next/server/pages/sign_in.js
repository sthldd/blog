module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 16);
/******/ })
/************************************************************************/
/******/ ({

/***/ 16:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("mTtV");


/***/ }),

/***/ "Exp3":
/***/ (function(module, exports) {

module.exports = require("antd");

/***/ }),

/***/ "adWu":
/***/ (function(module, exports) {



/***/ }),

/***/ "bwHk":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return withSession; });
/* harmony import */ var next_iron_session__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("rIpz");
/* harmony import */ var next_iron_session__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_iron_session__WEBPACK_IMPORTED_MODULE_0__);

function withSession(handler) {
  //@ts-ignore
  return Object(next_iron_session__WEBPACK_IMPORTED_MODULE_0__["withIronSession"])(handler, {
    // password: process.env.SECRET_COOKIE_PASSWORD,
    // 可以把密码放到本机上 export SECRET = 密码  然后用 process.env.SECRET来获取  next.js 用.env.local文件来存储
    password: process.env.SECRET,
    //应该是文件加密  
    cookieName: 'blog',
    //cookie的名字
    cookieOptions: {
      secure: false //secure 是只有在https下才生效 开发环境false

    }
  });
}

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "mTtV":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getServerSideProps", function() { return getServerSideProps; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("zr5I");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lib_withSession__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("bwHk");
/* harmony import */ var hooks_useForm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("wZYr");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("Exp3");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_sign_in_less__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("adWu");
/* harmony import */ var _styles_sign_in_less__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_sign_in_less__WEBPACK_IMPORTED_MODULE_5__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }






const layout = {
  labelCol: {
    span: 8
  },
  wrapperCol: {
    span: 16
  }
};
const tailLayout = {
  wrapperCol: {
    offset: 8,
    span: 16
  }
};

const SignIn = props => {
  const onSubmit = formData => {
    axios__WEBPACK_IMPORTED_MODULE_1___default.a.post(`/api/v1/sessions`, formData).then(() => {
      antd__WEBPACK_IMPORTED_MODULE_4__["message"].success('登陆成功');
      window.location.reload();
    }, error => {
      if (error.response) {
        const response = error.response;

        if (response.status === 422) {
          for (let key in response.data) {
            if (response.data[key].length > 0) {
              antd__WEBPACK_IMPORTED_MODULE_4__["message"].error(response.data[key][0]);
            }
          }

          setErrors(response.data);
        }
      }
    });
  };

  const initFormData = {
    username: '1234',
    password: '567'
  };
  const {
    form,
    setErrors
  } = Object(hooks_useForm__WEBPACK_IMPORTED_MODULE_3__[/* useForm */ "a"])({
    initFormData,
    fields: [{
      label: '用户名',
      type: 'text',
      key: 'username'
    }, {
      label: '密码',
      type: 'password',
      key: 'password'
    }],
    onSubmit,
    buttons: __jsx("button", {
      type: "submit"
    }, "\u767B\u9646")
  });
  return props.user ? __jsx("div", null, "\u5F53\u524D\u767B\u9646\u7528\u6237\uFF1A", props.user.username) : __jsx("div", {
    className: "login_modal_container"
  }, __jsx(antd__WEBPACK_IMPORTED_MODULE_4__["Form"], _extends({}, layout, {
    name: "basic",
    onFinish: onSubmit
  }), __jsx(antd__WEBPACK_IMPORTED_MODULE_4__["Form"].Item, {
    label: "Username",
    name: "username",
    rules: [{
      required: true,
      message: '请输入用户名'
    }]
  }, __jsx(antd__WEBPACK_IMPORTED_MODULE_4__["Input"], null)), __jsx(antd__WEBPACK_IMPORTED_MODULE_4__["Form"].Item, {
    label: "Password",
    name: "password",
    rules: [{
      required: true,
      message: '请输入密码'
    }]
  }, __jsx(antd__WEBPACK_IMPORTED_MODULE_4__["Input"].Password, null)), __jsx(antd__WEBPACK_IMPORTED_MODULE_4__["Form"].Item, tailLayout, __jsx(antd__WEBPACK_IMPORTED_MODULE_4__["Button"], {
    type: "primary",
    htmlType: "submit"
  }, "\u767B\u9646"))));
};

/* harmony default export */ __webpack_exports__["default"] = (SignIn);
const getServerSideProps = Object(lib_withSession__WEBPACK_IMPORTED_MODULE_2__[/* withSession */ "a"])(async context => {
  //@ts-ignore
  const user = context.req.session.get('currentUser'); //获取浏览器 application 中的cookie数据 存的时候在登陆存的

  return {
    props: {
      user: user ? JSON.parse(JSON.stringify(user)) : null
    }
  };
});

/***/ }),

/***/ "rIpz":
/***/ (function(module, exports) {

module.exports = require("next-iron-session");

/***/ }),

/***/ "wZYr":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return useForm; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


function useForm(options) {
  //useForm的data有个类型 就是initFormData的类型 不知道要传的什么类型参数 T就是占位符 useForm<T>的T就是声明T 占的就是initFormData的位
  const {
    initFormData,
    fields,
    onSubmit,
    buttons
  } = options;
  const {
    0: formData,
    1: setFormData
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(initFormData);
  const {
    0: errors,
    1: setErrors
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(() => {
    var e = {}; //声明的是 {user:['11']} 这种类型 ?代表我现在没有 等会可能会有

    for (let key in initFormData) {
      if (initFormData.hasOwnProperty(key)) {
        e[key] = [];
      }
    }

    return e;
  });
  const onchange = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])((key, value) => {
    setFormData(_objectSpread(_objectSpread({}, formData), {}, {
      [key]: value
    }));
  }, [formData]);

  const _onsubmit = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(e => {
    e.preventDefault();
    onSubmit(formData);
  }, [onSubmit, formData]);

  const form = __jsx("form", {
    onSubmit: _onsubmit
  }, fields.map((field, index) => {
    var _errors$field$key;

    return __jsx("div", {
      key: index
    }, __jsx("label", null, field.label, field.type === 'textarea' ? __jsx("textarea", {
      onChange: e => onchange(field.key, e.target.value),
      value: formData[field.key].toString()
    }) : __jsx("input", {
      type: field.type,
      value: formData[field.key].toString(),
      onChange: e => onchange(field.key, e.target.value)
    })), ((_errors$field$key = errors[field.key]) === null || _errors$field$key === void 0 ? void 0 : _errors$field$key.length) > 0 && __jsx("div", null, errors[field.key].join(',')));
  }), __jsx("div", null, buttons));

  return {
    form: form,
    setErrors: setErrors
  };
}

/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ })

/******/ });